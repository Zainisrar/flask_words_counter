# let's import the flask
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
@app.route('/home')  # this decorator creates the home route
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')




# Move the word_count() function outside of the result() function
def word_count(text):
    words_list = text.split()
    word_count_dict = {}

    for word in words_list:
        word_count_dict[word] = word_count_dict.get(word, 0) + 1

    return word_count_dict

@app.route('/result')
def result():
    para = request.args.get('results')  # Get the 'results' parameter from the query string
    char = len(para) - para.count(" ")
    words = len(para.split())
    
    # Counting the most frequently used word
    words_list = para.split()
    word_count_dict = {}
    for word in words_list:
        word_count_dict[word] = word_count_dict.get(word, 0) + 1
    most_frequent_word = max(word_count_dict, key=word_count_dict.get)

    result_dict = word_count(para)  # Use word_count() to get the word count result

    return render_template('result.html', char=char, word=words, most_words=most_frequent_word, result=result_dict)

@app.route('/analyzer', methods=['GET', 'POST'])
def analyzer():
    name = 'Text Analyzer'
    if request.method == 'GET':
        return render_template('analyzer.html', name=name, title=name)
    if request.method == 'POST':
        content = request.form['content']
        print(content)
        return redirect(url_for('result', results=content))

if __name__ == '__main__':
    app.run(debug=True)
